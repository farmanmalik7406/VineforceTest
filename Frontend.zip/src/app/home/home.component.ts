import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { CountrystateService } from '../countrystate.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  Countries:any;
  CountryForm: FormGroup = new FormGroup(
    {
      id : new FormControl(0),
      countryName : new FormControl("")
    }
  )
  constructor(private service:CountrystateService) { }

  ngOnInit(): void {
    this.GetAllCountries()
  }

  onSubmit(){
      this.service.AddEditCountry(this.CountryForm.value).subscribe(
        (data:any)=>{
          console.log(data);
          this.GetAllCountries()

        }
      )
  }

  onDelete(id : Number){
      this.service.DeleteCountry(id).subscribe(
        (x:any)=>this.GetAllCountries()
      )
  }


  onEdit(item:any){
    this.CountryForm.setValue(
      item
    )
  }
  GetAllCountries(){
    this.service.GetAllCountries().subscribe(
      (data:any)=>{
        console.log(data);
        this.Countries = data.data

      }
    )
  }

}
