import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { CountrystateService } from '../countrystate.service';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css']
})
export class StateComponent implements OnInit {

  States :any;
  Countries : any;
  StateForm = new FormGroup({
    id : new FormControl(0),
    stateName : new FormControl(""),
    countryId : new FormControl(0)
  })
  constructor(private service : CountrystateService) { }

  ngOnInit(): void {
    this.GetAllStates()
    this.GetAllCountries();
  }

  onSubmit(){
    this.StateForm.patchValue({
      countryId : Number(this.StateForm.value.countryId)
    })
    this.service.AddEditState(this.StateForm.value)
    .subscribe(
      (x:any)=>{
        console.log(x);

        this.GetAllStates()}
    );
  }

  GetCountry(id:Number){
      return this.Countries.find((x:any)=>x.id==id).countryName
  }

  onEdit(item:any){
    this.StateForm.setValue(item);
  }
  onDelete(id:Number){
    this.service.DeleteState(id).subscribe(
      (x:any)=> this.GetAllStates()
    )
  }
  GetAllCountries(){
    this.service.GetAllCountries().subscribe(
      (data:any)=>{
        console.log(data);
        this.Countries = data.data

      }
    )
  }

  GetAllStates()
  {
    this.service.GetAllStates().subscribe(
      (x:any)=>this.States=x.data
    );
  }
}
