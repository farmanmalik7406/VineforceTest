import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CountrystateService {

  constructor(private http : HttpClient) { }

  BASE_ADDR = "https://localhost:44387/api/"

  AddEditCountry(data:any){
        return this.http.post(this.BASE_ADDR+"Country/AddEditCountry",data)
  }

  DeleteCountry(id:Number){
    return this.http.delete(this.BASE_ADDR+"Country/DeleteCountry?id="+id);
  }

  GetAllCountries(){
    return this.http.get(this.BASE_ADDR+"Country/GetAllCountries");
  }

  AddEditState(data:any){
    return this.http.post(this.BASE_ADDR+"State/AddEditState",data)
  }

  DeleteState(id:Number){
  return this.http.delete(this.BASE_ADDR+"State/DeleteState?id="+id);
  }

  GetAllStates(){
  return this.http.get(this.BASE_ADDR+"State/GetAllStates");
  }
}
