﻿namespace VineforceDemoTest.Models
{
    public class ApiResponse
    {
        public int status { get; set; }
        public string message { get; set; }
        public object data { get; set; }
        public string version { get; set; }
    }
}
