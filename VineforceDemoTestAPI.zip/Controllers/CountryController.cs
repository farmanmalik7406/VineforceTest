﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VineforceDemoTest.Models;
using VineforceDemoTest.Services;

namespace VineforceDemoTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        ICountryServices _service;
        public CountryController(ICountryServices service)
        {
            _service = service;
        }

        [HttpPost]
        [Route("AddEditCountry")]
        public ApiResponse AddEditCountry(Country model)
        {
            return _service.AddEditCountry(model);
        }

        [HttpDelete]
        [Route("DeleteCountry")]
        public ApiResponse DeleteCountry(int id)
        {
            return _service.DeleteCountry(id);
        }

        [HttpGet]
        [Route("GetCountry")]
        public ApiResponse GetCountry(int id)
        {
            return _service.GetCountry(id);
        }

        [HttpGet]
        [Route("GetAllCountries")]
        public ApiResponse GetAllCountries()
        {
            return _service.GetAllCountries();
        }
    }
}
