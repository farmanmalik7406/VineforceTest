﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VineforceDemoTest.Models;
using VineforceDemoTest.Services;

namespace VineforceDemoTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StateController : ControllerBase
    {
        IStateServices _service;
        public StateController(IStateServices service)
        {
            _service = service;
        }

        [HttpPost]
        [Route("AddEditState")]
        public ApiResponse AddEditState(State model)
        {
            return _service.AddEditState(model);
        }

        [HttpDelete]
        [Route("DeleteState")]
        public ApiResponse DeleteState(int id)
        {
            return _service.DeleteState(id);
        }

        [HttpGet]
        [Route("GetState")]
        public ApiResponse GetState(int id)
        {
            return _service.GetState(id);
        }

        [HttpGet]
        [Route("GetAllStates")]
        public ApiResponse GetAllStates()
        {
            return _service.GetAllStates();
        }
    }
}
