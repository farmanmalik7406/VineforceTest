﻿using System;
using System.Linq;
using VineforceDemoTest.Models;

namespace VineforceDemoTest.Services
{
    public class StateServices : IStateServices
    {
        DemoDatabaseContext _context;
        public StateServices(DemoDatabaseContext context)
        {
            _context = context;
        }
        public ApiResponse AddEditState(State model)
        {
            try
            {
                if (model.Id==0)
                {
                    _context.Add(model);
                }
                else
                {
                    _context.Update(model);
                }
                _context.SaveChanges();
                return new ApiResponse()
                {
                    data = model,
                    message = "success",
                    status = 200,
                    version = "1.0"
                };
                
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }

        public ApiResponse DeleteState(int id)
        {
            try
            {
                _context.States.Remove(_context.States.FirstOrDefault(x=>x.Id==id));
                _context.SaveChanges();
                return new ApiResponse()
                {
                    data = null,
                    message = "success",
                    status = 200,
                    version = "1.0"
                };
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }

        public ApiResponse GetAllStates()
        {
            try
            {
                return new ApiResponse()
                {
                    data = _context.States.ToList(),
                    message = "success",
                    status = 200,
                    version = "1.0"
                };
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }

        public ApiResponse GetState(int id)
        {
            try
            {
                return new ApiResponse()
                {
                    data = _context.States.FirstOrDefault(x=>x.Id==id),
                    message = "success",
                    status = 200,
                    version = "1.0"
                };
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }
    }
}
