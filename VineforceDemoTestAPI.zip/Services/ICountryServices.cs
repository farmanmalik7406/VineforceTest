﻿using VineforceDemoTest.Models;

namespace VineforceDemoTest.Services
{
    public interface ICountryServices
    {
        ApiResponse AddEditCountry(Country model);
        ApiResponse DeleteCountry(int id);
        ApiResponse GetCountry(int id);
        ApiResponse GetAllCountries();
    }
}
