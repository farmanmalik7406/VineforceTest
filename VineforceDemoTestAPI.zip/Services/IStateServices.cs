﻿using VineforceDemoTest.Models;

namespace VineforceDemoTest.Services
{
    public interface IStateServices
    {
        ApiResponse AddEditState(State model);
        ApiResponse DeleteState(int id);
        ApiResponse GetState(int id);
        ApiResponse GetAllStates();
    }
}
