﻿using System;
using System.Linq;
using VineforceDemoTest.Models;

namespace VineforceDemoTest.Services
{
    public class CountryServices : ICountryServices
    {
        DemoDatabaseContext _context;
        public CountryServices(DemoDatabaseContext context)
        {
            _context = context;
        }
        public ApiResponse AddEditCountry(Country model)
        {
            try
            {
                if (model.Id == 0)
                {
                    _context.Countries.Add(model);
                }
                else
                {
                    _context.Countries.Update(model);
                }
                _context.SaveChanges();
                return new ApiResponse() { 
                    data = model,
                    message="success",
                    status=200,
                    version="1.0"
                };
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }

        public ApiResponse DeleteCountry(int id)
        {
            try
            {
                _context.Remove(_context.Countries.FirstOrDefault(x=>x.Id==id));
                _context.SaveChanges();
                return new ApiResponse()
                {
                    data = null,
                    message = "success",
                    status = 200,
                    version = "1.0"
                };
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }

        public ApiResponse GetAllCountries()
        {
            try
            {
                return new ApiResponse()
                {
                    data = _context.Countries.ToList(),
                    message = "success",
                    status = 200,
                    version = "1.0"
                };
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }

        public ApiResponse GetCountry(int id)
        {
            try
            {
                return new ApiResponse()
                {
                    data = _context.Countries.FirstOrDefault(x=>x.Id==id),
                    message = "success",
                    status = 200,
                    version = "1.0"
                };
            }
            catch (Exception ex)
            {

                return new ApiResponse()
                {
                    data = null,
                    message = ex.Message,
                    status = 400,
                    version = "1.0"
                };
            }
        }
    }
}
